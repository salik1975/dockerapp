$(document).ready(function () {

    $('#bSignin').on("click", signIn);
    $('#bClose').on("click", closeMe);
    ReadCookie();
});
function closeMe() {
    window.close();
}
function ReadCookie() {
    var allcookies = document.cookie;

    // Get all the cookies pairs in an array
    cookiearray = allcookies.split(',');
    console.log(cookiearray);

    // Now take key value pair out of this array
    for (var i = 0; i < cookiearray.length; i++) {
        name = cookiearray[i].split('=')[0];
        value = cookiearray[i].split('=')[1];

        var newvalue1 = name;
        var newvalue = value;
        if (i == 0) {
            $("#tclientID").val(newvalue);
            $("#input").val($("#tclientID").val());
        }
        else if (i == 1) {
            $("#tUserName").val(newvalue);
            $("#input").val($("#tUserName").val());
        }
        else if (i == 2) {
            $("#tPassword").val(newvalue);
            $("#input").val($("#tPassword").val());
        }

    }
}
function signIn() {
    var clientID = $("#tclientID").val();
    var userName = $("#tUserName").val();
    var pwd = $("#tPassword").val();

    var selectPageType = "";
    var rdopageType = $("input[type='radio'][name='PageType']:checked");
    if (rdopageType.length > 0) {
        selectPageType = rdopageType.val();
    }
   
    var expiration_date = new Date();
    var cookie_string = '';
    var result = '';
    expiration_date.setFullYear(expiration_date.getFullYear() + 1);
    document.cookie = "tclientID=" + clientID + "," + "tUserName=" + userName + "," + "tPassword=" + pwd + "," + "test_cookies=true; path=/; expires=" + expiration_date.toGMTString();
    if (!validate(clientID, userName, pwd)) {
        document.getElementById('demo').textContent = ("invalid credentials");
    }
    document.getElementById('demo').textContent = (clientID + userName + pwd);

    chrome.tabs.getSelected(null, function (tab) {

        chrome.tabs.sendRequest(tab.id, { clientID: clientID, userName: userName, password: pwd,pagetype:selectPageType }, function (response) {
            //console.log(response.result);
        });
    });
}

function validate(x, y, z) {
    if (x.length > 0 && y.length > 0 && z.length > 0) {
        return true;
    }
    else {
        alert("Blank not allowed !!")
        return false;
    }
}
