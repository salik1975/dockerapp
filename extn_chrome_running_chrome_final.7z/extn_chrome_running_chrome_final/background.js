chrome.runtime.onMessage.addListener(function(response,sender,sendResponse){alert("Hello");
                                                                           }
                                    );