chrome.extension.onRequest.addListener(function (request, sender, sendResponse) {

    try {        
        var restUrl = "https:/api.smartsearchonline.com/public/addcandidate.aspx";  
        alert('normal');
        //Modified code on 8th Nov 2019
        if ($('span.bkt4.name.userName').text().replace(/(^\s+|\s+$)/g, "")!="")   {  
           
            alert('inside normtal');
            var objEmployeeDetails = new getvalues();
            objEmployeeDetails.authcode  = 'DbvGbwDiAATmAlRZPyRTGAZwFDPAmPnT';
            objEmployeeDetails.client_num  = '998';          
            alert(JSON.stringify(objEmployeeDetails));                     
            callRest(restUrl, objEmployeeDetails);
            sendResponse({ result: "success" });           
        }        
    }
    catch (err) {
        console.log(err);
        sendResponse({ result: "failed" });
    }
});
/*
*  Escape newline chars for being transmitted with JSON over the wire
*/
function escapeNewLineChars(valueToEscape) {
    if (valueToEscape != null && valueToEscape != "") {
        return valueToEscape.replace(/(^\s+|\s+$)/g, "");
    } else {
        return valueToEscape;
    }
}

function callRest(restAddress, employeedetails) {
    jQuery.support.cors = true;
    $.ajax({
        url: restAddress,
        type: "POST",
        contentType: "application/json; charset=utf-8",
        dataType: 'json',
        data: escapeNewLineChars(JSON.stringify({ "item": employeedetails})),
        success: function (data) {
            alert(data.d);            
        },
        error: function (x, y, z) {
            alert("At this time, the tool only supports content from LInkedIN.com profiles");
           //console.log("REST API call failed with error:" + x.responseText + y + z);
        }
    });
}

function EmployeeDetails() {
  
    var first_name = '';
    var last_name  = '';
    var email = '';

    //Optional elemenet
    var candid  = '';
    var employeeid  = '';
    var jobid  = '';
    var homephone  = '';
    var cellphone  = '';
    var addr1  = '';    // 64 character max 
    var addr2  = ''; //30 character max 
    var city  = ''; // 64 character max 
    var state  = ''; //2 character max 
    var postalcode  = '';
    var country  = '';
    var relationship  = ''; //(“Current Employee”,”Former Employee” ,”Never Employee”,”Intern”,”Internal Employee”)
    var branch  = '';
    var source  = ''; //Must be an  EXACT match for  a value in your SmartSearch source drop down 
    var status  = ''; //Must be an  EXACT match for  a value in your SmartSearch status drop down 
    var status_date  = ''; // (mm/dd/yyyy) 
    var last_contact_date  = ''; // (mm/dd/yyyy) 
    var job_function  = ''; // (30 character max) 
    var filename  = ''; //name of primary resume (48 character max). 
    var resume =''; //base64 encoded version of primary resume (pdf,doc,docx, txt,htm,rtf) 

    
}
//Created These three new methods for sales start 

function getvalues() {
    var objEmployeeDetails = new EmployeeDetails();    
    var fullname = $('span.bkt4.name.userName').text().replace(/(^\s+|\s+$)/g, "");
    var arrname = fullname.split(" ");
    objEmployeeDetails.first_name = arrname[0];
    
    if (arrname[2]!=""){

        objEmployeeDetails.last_name = arrname[1] + " " + arrname[2]; 

    }else{

        objEmployeeDetails.last_name = arrname[1]; 
    } 
    alert(arrname[1] + arrname[2]); 

    objEmployeeDetails.cellphone = $('span.txt.num').text().replace(/(^\s+|\s+$)/g, "");  
    objEmployeeDetails.Email = $('span.txtGreen.bkt4.email').text().replace(/(^\s+|\s+$)/g, ""); 

    
    var href = $(this).attr('href');
    alert(href);
    //var xx = document.getElementById("cvDwldLink");
    //alert(xx.href);
    //xx.addEventListener("click", function(url){
     //   alert("Teest"+url);
        // Generate download of hello.txt file with some content
        //var text = document.getElementById("text-val").value;
        //var filename = "hello.txt";
        
        //download(filename, text);
    //}, false);

   // var resume = $('#cvDwldLink').attr('href'); 
   // alert(" Test" + resume); 

    objEmployeeDetails.CurrentLocation = $('li.t-16.t-black.t-normal.inline-block').text().replace(/(^\s+|\s+$)/g, "");
    objEmployeeDetails.Industry = $('span#ember92').text().replace(/(^\s+|\s+$)/g, "");;
    objEmployeeDetails.CurrentExp = '';// CurrentExp;
    objEmployeeDetails.PastExp = '';// PastExp;
    var Education = '';   
    objEmployeeDetails.Education = '';// Education;    
    
    objEmployeeDetails.Phone = $('.ci-phone').children('ul').children('li').children('div').text();
    objEmployeeDetails.IM = $('.ci-ims').children('ul').children('li').children('span').text();
    //objEmployeeDetails.Address = $("[id='relationship-address-view']").children(":first").text();
    objEmployeeDetails.PublicURL = window.location.href; 
    // }
    objEmployeeDetails.summary = $('.pv-top-card-section__summary').children('div').text();
    objEmployeeDetails.additionalinfo = ''// additionalinfo;    
    objEmployeeDetails.backgroundorganizations = ''// backgroundorganizations;    
    objEmployeeDetails.backgroundhonors = '';// backgroundhonors;    
    objEmployeeDetails.backgroundprojects = '';//backgroundprojects;    
    objEmployeeDetails.backgroundlanguages = '';// backgroundlanguages;
    //alert(JSON.stringify(objEmployeeDetails));
    return objEmployeeDetails;
}

